package com.example.registernotes;

public class Student {

    private  String Name;
    private String  LastName;
    private  String ID;
    private  double GradeNo1;
    private  double GradeNo2;
    private  double GradeNo3;
    private  double GradeFinal;

    public Student(String name, String lastName, String ID, double gradeNo1, double gradeNo2, double gradeNo3, double gradeFinal) {
        Name = name;
        LastName = lastName;
        this.ID = ID;
        GradeNo1 = gradeNo1;
        GradeNo2 = gradeNo2;
        GradeNo3 = gradeNo3;
        GradeFinal = gradeFinal;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public double getGradeNo1() {
        return GradeNo1;
    }

    public void setGradeNo1(double gradeNo1) {
        GradeNo1 = gradeNo1;
    }

    public double getGradeNo2() {
        return GradeNo2;
    }

    public void setGradeNo2(double gradeNo2) {
        GradeNo2 = gradeNo2;
    }

    public double getGradeNo3() {
        return GradeNo3;
    }

    public void setGradeNo3(double gradeNo3) {
        GradeNo3 = gradeNo3;
    }

    public double getGradeFinal() {
        return GradeFinal;
    }

    public void setGradeFinal(double gradeFinal) {
        GradeFinal = gradeFinal;
    }

    public void Register(){
        Data.Save(this);
    }
}

