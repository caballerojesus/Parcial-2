package com.example.registernotes;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class StudentList extends AppCompatActivity {

    private ListView LV;
    private ArrayList<Student> Student;
    private ArrayList<String> StudentName;
    private Intent IN;
    private TextView NoResults;

    @Override
    protected  void  onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_list);

        LV=(ListView) findViewById(R.id.ListStudent);
        NoResults = (TextView) findViewById(R.id.NoResults);
        Student = Data.Get();
        StudentName = new ArrayList<String>();

        NoResults.setVisibility(View.VISIBLE);
        LV.setVisibility(View.INVISIBLE);

        if (Student.size() > 0){
            LV.setVisibility(View.VISIBLE);
            NoResults.setVisibility(View.INVISIBLE);

            for (int i = 0; i < Student.size() ; i++){
                StudentName.add(Student.get(i).getName() + " " + Student.get(i).getLastName()+ " - "+Student.get(i).getGradeFinal());
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, StudentName);
        LV.setAdapter(adapter);


        LV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                IN = new Intent(StudentList.this, StudentD.class);
                IN.putExtra("position", position);
                startActivity(IN);
            }
        });

    }
}
