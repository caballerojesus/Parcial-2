package com.example.registernotes;

import java.util.ArrayList;

public class Data {

    private static ArrayList<Student> Student = new ArrayList<>();
    public static void Save(Student s){Student.add(s);}
    public static ArrayList<Student> Get(){return Student;}
}

