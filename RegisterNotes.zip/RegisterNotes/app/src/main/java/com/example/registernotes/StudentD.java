package com.example.registernotes;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import java.util.ArrayList;

public class StudentD extends AppCompatActivity {
    private Intent In;
    private ArrayList<Student> Students;
    private TextView Name, ID, GradeOne, GradeTwo, GradeThree, FinalGrade;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_detail);

        In = getIntent();
        Students=Data.Get();

        int Position = In.getIntExtra("position", 0);

        Name = (TextView)findViewById(R.id.StudentcompleteName);
        ID = (TextView)findViewById(R.id.SID);
        GradeOne = (TextView)findViewById(R.id.SGradeNo1);
        GradeTwo = (TextView)findViewById(R.id.SGradeNo2);
        GradeThree = (TextView)findViewById(R.id.SGradeNo3);
        FinalGrade = (TextView)findViewById(R.id.GradeFinal);

        loadData(Students.get(Position));

    }

    private void loadData(Student Student){
        Name.setText(Student.getName() + " " + Student.getLastName());
        ID.setText(Student.getID());
        GradeOne.setText(Double.toString(Student.getGradeNo1()));
        GradeTwo.setText(Double.toString(Student.getGradeNo2()));
        GradeThree.setText(Double.toString(Student.getGradeNo3()));
        FinalGrade.setText(Double.toString(Student.getGradeFinal()));

    }
}

