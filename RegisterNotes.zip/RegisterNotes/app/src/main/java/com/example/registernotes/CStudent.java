package com.example.registernotes;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class CStudent extends AppCompatActivity {
    private EditText Name, LastName, ID, GradeOne, GradeTwo, GradeThree;
    private android.content.res.Resources Resources;
    private ArrayList<Student> student;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_student);

        Name = (EditText)findViewById(R.id.SName);
        LastName = (EditText)findViewById(R.id.SLastName);
        ID = (EditText)findViewById(R.id.SID);
        GradeOne = (EditText)findViewById(R.id.SGradeNo1);
        GradeTwo = (EditText)findViewById(R.id.SGradeNo2);
        GradeThree = (EditText)findViewById(R.id.SGradeNo3);

        Resources = this.getResources();
        student = Data.Get();
    }

    public void Save(View view){
        String NameV, LastNameV,  GradeOneV, GradeTwoV, GradeThreeV, IDV;
        IDV = ID.getText().toString();;
        NameV = Name.getText().toString();
        LastNameV = LastName.getText().toString();
        GradeOneV = GradeOne.getText().toString();
        GradeTwoV = GradeTwo.getText().toString();
        GradeThreeV = GradeThree.getText().toString();

        double GV1 = Double.parseDouble(GradeOneV), GV2 = Double.parseDouble(GradeTwoV), GV3 = Double.parseDouble(GradeThreeV);

        Student S = new Student(NameV, LastNameV, IDV, GV1, GV2, GV3, (GV1+GV2+GV3)/3);
        S.Register();
        Toast.makeText(this, R.string.create_student, Toast.LENGTH_LONG).show();

    }
}
